# Changelog

## 2017-14-11

- Contact links were fixed [https://github.com/SteveLane/hugo-icon/issues/3](https://github.com/SteveLane/hugo-icon/issues/3) (@MartinWillitts)
    - Slight change to original main.js
- A linkedin option was added to configuration (@MartinWillitts)

## 2017-09-21

- Theme ported to Hugo with no changes made to styling/theming.
- Adjusted contact form to work with netlify
